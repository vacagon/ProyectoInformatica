#include <gtest/gtest.h>
#include <time.h>
#include "../Manager.hpp"
#include <fstream>
#include <sstream>
